<?php
add_action( 'rest_api_init', function () {
    register_rest_route( 'myapi/v1', '/author/', array(
      'methods' => 'POST',
      'callback' => 'equipment_insert',
    ) );
  });
function add_my_stylesheet() 
{
    wp_enqueue_style( 'bootstrap.min', plugins_url( '/template/css/bootstrap.min.css', __FILE__ ) );
     wp_enqueue_style( 'dataTables.min', plugins_url( '/template/css/dataTables.min.css', __FILE__ ) );
    wp_enqueue_script( 'jquery.min', plugins_url( '/template/js/jquery.min.js', __FILE__ ) );
    wp_enqueue_script( 'popper.min', plugins_url( '/template/js/popper.min.js', __FILE__ ) );
    wp_enqueue_script( 'bootstrap.min', plugins_url( '/template/js/bootstrap.min.js', __FILE__ ) );
    wp_enqueue_script( 'bootbox.min', plugins_url( '/template/js/bootbox.min.js', __FILE__ ) );
    wp_enqueue_script( 'customJs', plugins_url( '/template/js/customJs.js', __FILE__ ) );
    wp_enqueue_script( 'dataTables.min', plugins_url( '/template/js/dataTables.min.js', __FILE__ ) );
}

  add_action('admin_print_styles', 'add_my_stylesheet');
  

function equipment_insert()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'excercise';
    $result = $wpdb->get_results("SELECT * from $table_name");

    $table_name1 = $wpdb->prefix . 'target_equipment';
    $result1 = $wpdb->get_results("SELECT * from $table_name1");

    $log_entry_tbl = $wpdb->prefix . 'log_entry_option';
    $log_entries = $wpdb->get_results("SELECT * from $log_entry_tbl");
  
?>
  <div class="container">
    <h2>Stacked form</h2>
    <form action=""  method="post" id="emp_for,""m" enctype="multipart/form-data" onsubmit="return valid()">
      <!-- Excercise Name--> 
      <div class="form-group">
        <label >Excercise Name :</label>
        <input type="text" class="form-control" name="name" placeholder="Excercise Name">
      </div>
      <!-- Excercise Description --> 
      <div class="form-group">
        <label >Excercise Description :</label>
        <textarea name="description" class="form-control" placeholder="Excercise Description"></textarea>
      </div>
      <!-- Excercise --> 
      <div class="form-group">
        <label >Excercise Type :</label>
        <select name="excercise" id="excercise" class="form-control">
        <option value="">--- Excercise ---</option>
        	<?php
            foreach ($result as $res) {
              echo "<option value=$res->id>$res->excercise</option>";
             }
          ?>
        </select>
      </div>
      <!-- Target Region --> 
      <div class="form-group" id="target_region_group">
        <label >Target Region:</label>
        <select name="target_region" id="target_region" class="form-control">
        	<option value="">--- Target Region  ---</option>
        </select>
      </div>
      <!-- Target Muscle --> 
      <div class="form-group" id="muscle_group"> 
        <label >Target Muscle:</label>
        <select name="target_muscle" id="muscle" class="form-control">
        	<option value="">--- Target Muscle ---</option>
        </select>
      </div>
      <!-- Equipments --> 
      <div class="form-group" id="equipments-group">
        <label >Equipments:</label>
        <select name="equipments" id="equipments" class="form-control">
          <option value="">--- Equipment ---</option>
          <?php
            foreach ($result1 as $res) {
              echo "<option value=$res->id>$res->equipment</option>";
             }
          ?>
        </select>
      </div>
      <!-- Difficulty Level --> 
      <div class="form-group">
        <label >Difficulty Level:</label>
        <select name="level" id="level" class="form-control">
          <option value="">--- Difficulty Level ---</option>
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanceed">Advanceed</option>
          <option value="none">None</option>
        </select>
      </div>
      <!-- Duration --> 
      <div class="form-group" id="duration_group">
        <label >Duration:</label>
        <select name="duration" id="duration" class="form-control">
          <option value="">--- Duration ---</option>
          <?php
            foreach ($log_entries as $res) {
              echo "<option value=$res->duration>$res->duration</option>";
             }
          ?>
        </select>
      </div>
      
      <!-- Distance --> 
      <div class="form-group" id="discance_group">
        <label >Distance:</label>
        <select name="distance" id="distance" class="form-control">
          <option value="">--- Distance ---</option>
          <?php
            foreach ($log_entries as $res) {
              echo "<option value=$res->duration>$res->duration</option>";
             }
          ?>
        </select>
      </div>
      <!-- Speed --> 
      <div class="form-group" id="speed_group">
        <label >Speed:</label>
        <select name="speed" id="speed" class="form-control">
          <option value="">--- Speed ---</option>
          <?php
            foreach ($log_entries as $res) {
              echo "<option value=$res->duration>$res->duration</option>";
             }
          ?>
        </select>
      </div>
      <!-- Calories --> 
      <div class="form-group" id="calories_group">
        <label >Calories:</label>
        <select name="calories" id="calories" class="form-control">
          <option value="">--- Calories ---</option>
          <?php
            foreach ($log_entries as $res) {
              echo "<option value=$res->duration>$res->duration</option>";
             }
          ?>
        </select>
      </div>
      
      <!-- Upload Media --> 
      <div class="form-group" >
        <label >Upload Media:</label>
        <input type="file" name="file" class="form-control">
      </div>
      <button type="submit" name="insert" id="insert" class="btn btn-primary">Add</button>
    </form>
  </div>
  <script type="text/javascript">
      $("#target_region_group").css("display", "none");
      $("#muscle_group").css("display", "none");
      $("#equipments-group").css("display", "none");
      $("#duration_group").css("display", "none");
      $("#discance_group").css("display", "none");
      $("#speed_group").css("display", "none");
      $("#calories_group").css("display", "none");
   // on excercise change
   $('#excercise').on('change', function() {
           var id = $(this).val();
           if(id != 1){
             $("#target_region_group").css("display", "none");
             $("#muscle_group").css("display", "none");
             $("#equipments-group").css("display", "none");
           }
           else {
            $("#target_region_group").css("display", "block");
            $("#muscle_group").css("display", "block");
            $("#equipments-group").css("display", "block");
           }
           if(id != 2){
             $("#duration_group").css("display", "none");
             $("#discance_group").css("display", "none");
             $("#speed_group").css("display", "none");
             $("#calories_group").css("display", "none");
           }
           else {
            $("#duration_group").css("display", "block");
            $("#discance_group").css("display", "block");
            $("#speed_group").css("display", "block");
            $("#calories_group").css("display", "block");
           }
           if(id ==3) {
            $("#target_region_group").css("display", "block");
           }
          jQuery.ajax({
            url : '<?php echo admin_url('admin-ajax.php'); ?>',
            type : 'post',
            data : {
              action : 'my_target_region',
              excercise_id : id,
            },
            success : function( html ) {
              $("#target_region").html(html);
            }
          });
    });
   // on Category change
   $('#target_region').on('change', function() {
           var id = $(this).val();
          jQuery.ajax({
            url : '<?php echo admin_url('admin-ajax.php'); ?>',
            type : 'post',
            data : {
              action : 'my_target_muscle',
              muscle_id : id,
            },
            success : function( html ) {
              $("#muscle").html(html);
            }
          });
    });

   $('#hasEquipment').on('change', function() {
      if(this.checked != true){
         $("#equipments-group").css("display", "none");
       }
       else {
        $("#equipments-group").css("display", "block");
       }
    });
  
  </script>

  <?php
	if(isset($_POST['insert'])  )
	{
    global $wpdb;
    $name=$_POST['name'];
    $description=$_POST['description'];	
	 	$excercise=$_POST['excercise'];
	 	$target_region=$_POST['target_region'];
    $target_muscle=$_POST['target_muscle'];
    $duration=$_POST['duration'];
    $distance=$_POST['distance'];
    $speed=$_POST['speed'];
    $calories=$_POST['calories'];
    $level=$_POST['level'];
    $equipments=$_POST['equipments'] ? $_POST['equipments'] : '';
    $file_name=$_FILES['file'] ? $_FILES['file']['name'] : '';

		$table_name = $wpdb->prefix . 'custom_equipment';
		
		$wpdb->insert($table_name,
		            array(
                    'name' => $name,
                    'description' => $description,                  
		                'excercise' => $excercise,
		                'target_region' => $target_region,
                    'target_muscle' => $target_muscle,
                    'duration' => $duration,
                    'distance' => $distance,
                    'speed' => $speed,
                    'calories' => $calories,
                    'difficulty_level' => $level,
                    'equipments' => $equipments,
                    'media' => $file_name
		            )
            );

      // move file
      require_once(ABSPATH . "wp-admin" . '/includes/image.php');
      require_once(ABSPATH . "wp-admin" . '/includes/file.php');
      require_once(ABSPATH . "wp-admin" . '/includes/media.php');
      $file_id = media_handle_upload( 'file', $post->ID );
  		
  		echo "<script>
        bootbox.alert({
  			    message:'Data Is Sucessfully Inserted!',
  			    size: 'small'
  			});
  		 </script>";
	}
}

// target region
  function target_region() 
  {
    $id=$_POST['excercise_id'];
    global $wpdb;
    $table_name = $wpdb->prefix.'target_region';
    $result = $wpdb->get_results("SELECT * from $table_name  where  excercise_id=$id");
    echo "<option>--- Target Region ---</option>";
    foreach ($result as $res) {
              echo "<option value=$res->id>$res->target_region</option>";
    }
  }
  add_action( 'wp_ajax_my_target_region', 'target_region' );
  add_action( 'wp_ajaxn_nopriv_my_target_region', 'target_region' );

  // target muscle
  function target_muscle() 
  {
    $id=$_POST['muscle_id'];
    global $wpdb;
    $table_name = $wpdb->prefix.'target_muscle';
    $result = $wpdb->get_results("SELECT * from $table_name  where  target_region_id=1");
    echo "<option>--- Target Muscle ---</option>";
    foreach ($result as $res) {
              echo "<option value=$res->id>$res->target_muscle</option>";
    }
  }
  add_action( 'wp_ajax_my_target_muscle', 'target_muscle' );
  add_action( 'wp_ajaxn_nopriv_my_target_muscle', 'target_muscle' );

?>

