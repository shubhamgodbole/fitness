<?php
add_action( 'rest_api_init', function () {
  register_rest_route( 'fetchdata', '/equipment/(?P<id>\d+)', array(
    'methods' => 'GET',
    'callback' => 'my_func',
  ) );
} );

function my_func( $data ) {
	$id = $data['id'];
	global $wpdb;
	$table_name = $wpdb->prefix . 'custom_equipment';
	$result = $wpdb->get_results("SELECT * from $table_name where id = $id");
  	return $response = new WP_REST_Response($result);
}


add_action( 'rest_api_init', function () {
    register_rest_route( 'fetchdata', '/equipment/', array(
      'methods' => 'GET',
      'callback' => 'equipment_list',
    ) );
  });
function equipment_list()
{
?>

<br><br><br>
<div class="container">
    <div><a class="btn btn-primary" style="float:right" href="<?php echo admin_url('/admin.php?page=Equipment_Insert') ?>"> Add New </a> </div>
    <br><br>
<table class="table" id="myTable">
	<thead>
		<tr>
			<th>Name</th>
			<th>Description</th>
			<th>Excercise</th>
			<th>Target Region</th>	
			<th>Target Muscle</th>
			<th>Duration</th>
			<th>DIstance</th>
			<th>Speed</th>
			<th>Calories</th>
			<th>Difficulty Level</th>
			<th>Equipments</th>
			<th>Download Media</th>
		</tr>
	</thead>
	<?php
		 global $wpdb;
		 $table_name = $wpdb->prefix . 'custom_equipment';
		 $qry ="SELECT wp_custom_equipment.id,wp_custom_equipment.name,wp_custom_equipment.description,wp_excercise.excercise,wp_target_region.target_region,wp_target_muscle.target_muscle,wp_custom_equipment.duration,wp_custom_equipment.distance,wp_custom_equipment.speed,wp_custom_equipment.calories,wp_target_equipment.equipment,wp_custom_equipment.difficulty_level,wp_custom_equipment.media FROM wp_custom_equipment,wp_target_muscle,wp_target_region,wp_excercise,wp_target_equipment WHERE wp_custom_equipment.target_muscle = wp_target_muscle.id and wp_custom_equipment.target_region = wp_target_region.id AND wp_custom_equipment.excercise = wp_excercise.id AND wp_custom_equipment.equipments = wp_target_equipment.id";
		 $result = $wpdb->get_results($qry);
		 foreach ($result as $res) {
                $edit_url=admin_url('/admin.php?page=Employee_Update&id='.$res->id);
		 	echo "<tr>
		 				<td>$res->name</td>
		 				<td>$res->description</td>
		 				<td>$res->excercise</td>
		 				<td>$res->target_region</td>
		 				<td>$res->target_muscle</td>
		 				<td>$res->duration</td>
		 				<td>$res->distance</td>
		 				<td>$res->speed</td>
		 				<td>$res->calories</td>
		 				<td>$res->difficulty_level</td>
		 				<td>$res->equipment</td>
		 				<td><a href=../wp-content/uploads/2018/10/$res->media target=_blank>Download </a></td>
		 		</tr>";
		 }
	?>
	<tfoot>
		<tr>		
			<th>Name</th>
			<th>Description</th>
			<th>Excercise</th>
			<th>Target Region</th>	
			<th>Target Muscle</th>
			<th>Duration</th>
			<th>DIstance</th>
			<th>Speed</th>
			<th>Calories</th>
			<th>Difficulty Level</th>
			<th>Equipments</th>
			<th>Download Media</th>
		</tr>
	</tfoot>


</table>
</div>
<script type="text/javascript">
	$(document).ready(function(){
	    $('#myTable').DataTable();
	});
</script>
<?php
return $response = new WP_REST_Response($result);

}

?>